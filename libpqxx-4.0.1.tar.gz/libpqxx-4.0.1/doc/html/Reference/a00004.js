var a00004 =
[
    [ "argument_error", "a00004.html#a1b68c0e492e7cb4f9458ca0de1b85862", null ]
];
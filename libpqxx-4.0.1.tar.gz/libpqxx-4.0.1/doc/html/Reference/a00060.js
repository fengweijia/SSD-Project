var a00060 =
[
    [ "nontransaction", "a00060.html#a8ed8b2f6aa96cef8508c84ee5369b390", null ],
    [ "~nontransaction", "a00060.html#a0069617cbc84ba559bdcdfdf3cd97f3b", null ]
];
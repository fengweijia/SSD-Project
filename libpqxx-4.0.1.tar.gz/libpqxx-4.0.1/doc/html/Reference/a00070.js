var a00070 =
[
    [ "plpgsql_no_data_found", "a00070.html#ab6013cc52171417e60008c1efebd4257", null ],
    [ "plpgsql_no_data_found", "a00070.html#a97cfb947332b3e275e3437b5284de8ff", null ]
];
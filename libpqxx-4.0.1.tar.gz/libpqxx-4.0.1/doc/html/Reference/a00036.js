var a00036 =
[
    [ "errorhandler", "a00036.html#a4627d71dc5156998ab1a8705fe5db974", null ],
    [ "~errorhandler", "a00036.html#a102761e1ec70d1f2d339d250bcdc799c", null ],
    [ "operator()", "a00036.html#a31238a2ce8999c76725a6d045dcc942f", null ],
    [ "internal::gate::errorhandler_connection_base", "a00036.html#a08b329d18887eeb882ff0c80b8ae74ba", null ]
];
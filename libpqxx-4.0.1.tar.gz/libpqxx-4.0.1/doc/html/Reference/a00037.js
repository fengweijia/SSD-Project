var a00037 =
[
    [ "Escaper", "a00037.html#ae038cf7f50b925680be254201b2cdeaa", null ],
    [ "operator()", "a00037.html#aa93a0d1009d7900066cdb3893b4a25b2", null ]
];
var a00011 =
[
    [ "isolation_tag", "a00011.html#aad0757a015b2ddfe476e3d83f812bbff", null ],
    [ "~basic_robusttransaction", "a00011.html#a4fa796f8dff9f236c36f292898eaeaad", null ],
    [ "basic_robusttransaction", "a00011.html#a0761b12be4f64a7bccba1d2e7bf3d4a2", null ]
];
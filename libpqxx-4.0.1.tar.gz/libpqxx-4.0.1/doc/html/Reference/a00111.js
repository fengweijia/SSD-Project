var a00111 =
[
    [ "unique", "a00111.html#a7dce0951d8eff0a8d156ff1b73e2c878", null ],
    [ "get", "a00111.html#a9a6ace7374f5ed24d77d6e760e186d8b", null ],
    [ "Register", "a00111.html#a20d41d4090254a82c02f1d7e30af9d04", null ],
    [ "Unregister", "a00111.html#afd6cf65f79200733565eb68f9085611a", null ]
];
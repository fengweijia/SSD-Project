var a00194 =
[
    [ "gate", "a00195.html", null ],
    [ "reactivation_avoidance_counter", "a00078.html", "a00078" ],
    [ "reactivation_avoidance_exemption", "a00079.html", "a00079" ],
    [ "sql_cursor", "a00085.html", "a00085" ],
    [ "notify_listener_forwarder", "a00064.html", "a00064" ],
    [ "Escaper", "a00037.html", "a00037" ],
    [ "transactionfocus", "a00105.html", "a00105" ],
    [ "parameterized_invocation", "a00067.html", "a00067" ],
    [ "dereference", "a00034.html", "a00034" ],
    [ "deref_ptr", "a00033.html", "a00033" ],
    [ "refcount", "a00080.html", "a00080" ],
    [ "PQAlloc", "a00073.html", "a00073" ],
    [ "scoped_array", "a00084.html", "a00084" ],
    [ "namedclass", "a00059.html", "a00059" ],
    [ "unique", "a00111.html", "a00111" ]
];
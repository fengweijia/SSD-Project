var a00196 =
[
    [ "internal", "a00197.html", "a00197" ],
    [ "invocation", "a00053.html", "a00053" ]
];
var a00064 =
[
    [ "notify_listener_forwarder", "a00064.html#ade491702e92e9e98b540c57d53b896db", null ],
    [ "operator()", "a00064.html#aa09aa1f99cc15c8f9ffb8ff5478ecd01", null ]
];
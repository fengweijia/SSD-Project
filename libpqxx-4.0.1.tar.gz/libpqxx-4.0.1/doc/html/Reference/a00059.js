var a00059 =
[
    [ "namedclass", "a00059.html#ad703d52d9d96025bf08d9da26f6829be", null ],
    [ "classname", "a00059.html#a9c216366ea21f1c9cd03b39410185cbb", null ],
    [ "description", "a00059.html#ab63de628429e771251ab8a2688ad407d", null ],
    [ "name", "a00059.html#a79dcce75176eef9d2d80fdc2ec2827a7", null ]
];
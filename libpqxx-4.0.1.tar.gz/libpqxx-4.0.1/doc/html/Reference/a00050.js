var a00050 =
[
    [ "invalid_cursor_name", "a00050.html#aaa48cdbce346a4c8e593a3dbe8d06fcd", null ],
    [ "invalid_cursor_name", "a00050.html#aa73214eba77d9c6cd048ea04f3f20c28", null ]
];
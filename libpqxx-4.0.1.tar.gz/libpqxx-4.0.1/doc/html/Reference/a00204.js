var a00204 =
[
    [ "connect_direct", "a00020.html", null ],
    [ "connect_lazy", "a00021.html", null ],
    [ "connect_async", "a00019.html", null ],
    [ "connect_null", "a00022.html", null ],
    [ "connectionpolicy", "a00024.html", null ],
    [ "asyncconnection", "a00204.html#ga710db2d58482a4ea8ebbb822c2b0d417", null ],
    [ "connection", "a00204.html#ga26edb910e4563d1115e22c627914e98b", null ],
    [ "lazyconnection", "a00204.html#ga8911912522c75dd0b154fefdde735272", null ],
    [ "nullconnection", "a00204.html#ga830f18f804ec3e4cc8bab713169fb529", null ]
];
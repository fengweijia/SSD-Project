var a00052 =
[
    [ "invalid_sql_statement_name", "a00052.html#a733530a1cdef5f0c73c57ff4d46b3ae3", null ],
    [ "invalid_sql_statement_name", "a00052.html#ab6cdfc77425f86d8f15af9726e079824", null ]
];
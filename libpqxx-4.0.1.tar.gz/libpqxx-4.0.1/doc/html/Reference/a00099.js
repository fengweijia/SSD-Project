var a00099 =
[
    [ "tablestream", "a00099.html#a5cfaacb3b52d957c8df94b91f3f1fe40", null ],
    [ "~tablestream", "a00099.html#a6d024cd5f02bb5c2a6eb00ca11bde772", null ],
    [ "base_close", "a00099.html#a8206b4b9b8dc8139e7b9be97d3c91d95", null ],
    [ "columnlist", "a00099.html#ae36c9e2bd18b6ed8a6c942ba616154b2", null ],
    [ "complete", "a00099.html#a0241100d03b034b8e7b59201a6a1b88f", null ],
    [ "is_finished", "a00099.html#a48f61b76226df70a8eaa334b6f53575a", null ],
    [ "NullStr", "a00099.html#afdac33bb17371652a6328b689d29a411", null ]
];
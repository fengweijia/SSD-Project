var a00054 =
[
    [ "level", "a00054.html#a7257515292c662b6247844ddbbd5d37d", null ],
    [ "name", "a00054.html#aa70d28518dfd8e0021c76e50e19da150", null ],
    [ "name", "a00054.html#aa614c41bb7460c52684cbcc058a96ec3", null ],
    [ "name", "a00054.html#a5ea14e6598a2e7ac7b0ad7e1a9610873", null ],
    [ "name", "a00054.html#ab448a03b23a8e86e12cb21f495d941fc", null ]
];